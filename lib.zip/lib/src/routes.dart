import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/onboarding/welcome_screen.dart';
import 'screens/onboarding/login_screen.dart';
import 'screens/onboarding/register_screen.dart';
import 'screens/onboarding/forgot_password_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/recipes/recipes_screen.dart';
import 'screens/recipes/add_edit_recipe_screen.dart';
import 'screens/recipe_details/recipe_details_screen.dart';
import 'screens/inventory/inventory_screen.dart';
import 'screens/meal_planner/meal_planner_screen.dart';
import 'screens/shopping_list/shopping_list_screen.dart';
import 'screens/ai_recipe/ai_recipe_screen.dart';
import 'screens/analytics/analytics_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/settings/settings_screen.dart';
import 'services/auth_service.dart';

class AppRoutes {
  static Map<String, WidgetBuilder> routes = {
    '/': (context) {
      // Check if user is logged in and return appropriate screen
      final authService = Provider.of<AuthService>(context, listen: false);
      return authService.currentUser != null
          ? const HomeScreen()
          : const WelcomeScreen();
    },
    '/login': (context) => const LoginScreen(),
    '/register': (context) => const RegisterScreen(),
    '/forgot-password': (context) => const ForgotPasswordScreen(),
    '/home': (context) => const HomeScreen(),
    '/dashboard': (context) => const DashboardScreen(),
    '/recipes': (context) => const RecipesScreen(),
    '/add-recipe': (context) => const AddEditRecipeScreen(),
    '/inventory': (context) => const InventoryScreen(),
    '/meal-planner': (context) => const MealPlannerScreen(),
    '/shopping-list': (context) => const ShoppingListScreen(),
    '/ai-recipe': (context) => const AIRecipeScreen(),
    '/analytics': (context) => const AnalyticsScreen(),
    '/profile': (context) => const ProfileScreen(),
    '/settings': (context) => const SettingsScreen(),
  };

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    if (settings.name == '/recipe-details') {
      final args = settings.arguments as String;
      return MaterialPageRoute(
        builder: (context) => RecipeDetailsScreen(recipeId: args),
      );
    }

    if (settings.name == '/edit-recipe') {
      final args = settings.arguments as String;
      return MaterialPageRoute(
        builder: (context) => AddEditRecipeScreen(recipeId: args),
      );
    }

    // Check if the route is in our routes map
    if (routes.containsKey(settings.name)) {
      return MaterialPageRoute(
        builder: routes[settings.name]!,
        settings: settings,
      );
    }

    // If we get here, no route was found
    return MaterialPageRoute(
      builder: (context) => Scaffold(
        appBar: AppBar(title: const Text('Not Found')),
        body: Center(
          child: Text('Route ${settings.name} not found'),
        ),
      ),
    );
  }
}
