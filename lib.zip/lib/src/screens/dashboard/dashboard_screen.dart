import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../services/auth_service.dart';
import '../../services/meal_plan_service.dart';
import '../../services/inventory_service.dart';
import '../../models/meal_plan_model.dart';
import '../../models/inventory_item_model.dart';
import '../../widgets/glass_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final theme = Theme.of(context);
    
    return Scaffold(
      body: FutureBuilder(
        future: authService.getUserData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          
          final userData = snapshot.data;
          
          if (userData == null) {
            return const Center(child: Text('User data not found'));
          }
          
          return CustomScrollView(
            slivers: [
              // App Bar
              SliverAppBar(
                expandedHeight: 200,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  title: Text(
                    'Welcome, ${userData.displayName?.split(' ')[0] ?? 'Chef'}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        'assets/images/dashboard_header.jpg',
                        fit: BoxFit.cover,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.7),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.notifications),
                    onPressed: () {
                      // TODO: Navigate to notifications
                    },
                  ),
                ],
              ),
              
              // Dashboard Content
              SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    // Today's Date
                    Text(
                      DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now()),
                      style: theme.textTheme.titleLarge,
                    ),
                    const SizedBox(height: 24),
                    
                    // Today's Meals
                    _buildTodaysMeals(context, userData.uid),
                    const SizedBox(height: 24),
                    
                    // Expiring Items
                    _buildExpiringItems(context, userData.uid),
                    const SizedBox(height: 24),
                    
                    // Quick Actions
                    _buildQuickActions(context),
                    const SizedBox(height: 24),
                    
                    // Nutrition Summary
                    _buildNutritionSummary(context, userData.uid),
                  ]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
  
  Widget _buildTodaysMeals(BuildContext context, String userId) {
    final theme = Theme.of(context);
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Today\'s Meals',
              style: theme.textTheme.headlineMedium,
            ),
            TextButton(
              onPressed: () {
                // Navigate to meal planner
                Navigator.pushNamed(context, '/meal-planner');
              },
              child: const Text('View All'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        StreamBuilder<List<MealPlanModel>>(
          stream: Provider.of<MealPlanService>(context).getMealPlans(
            userId,
            startOfDay,
            endOfDay,
          ),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            
            final mealPlans = snapshot.data ?? [];
            
            if (mealPlans.isEmpty) {
              return GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.restaurant,
                      size: 48,
                      color: Colors.grey,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'No meals planned for today',
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () {
                        // Navigate to add meal
                        Navigator.pushNamed(context, '/add-meal');
                      },
                      child: const Text('Add Meal'),
                    ),
                  ],
                ),
              );
            }
            
            final meals = mealPlans.first.meals;
            
            return SizedBox(
              height: 180,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: meals.length,
                itemBuilder: (context, index) {
                  final meal = meals[index];
                  return Container(
                    width: 160,
                    margin: const EdgeInsets.only(right: 16),
                    child: GlassCard(
                      padding: EdgeInsets.zero,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                            ),
                            child: Image.network(
                              meal.recipeImageUrl ?? 'https://via.placeholder.com/160x100',
                              height: 100,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  meal.mealType.toUpperCase(),
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  meal.recipeName,
                                  style: theme.textTheme.titleMedium,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '${meal.servings} serving${meal.servings > 1 ? 's' : ''}',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ],
    );
  }
  
  Widget _buildExpiringItems(BuildContext context, String userId) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Expiring Soon',
              style: theme.textTheme.headlineMedium,
            ),
            TextButton(
              onPressed: () {
                // Navigate to inventory
                Navigator.pushNamed(context, '/inventory');
              },
              child: const Text('View All'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        StreamBuilder<List<InventoryItemModel>>(
          stream: Provider.of<InventoryService>(context).getExpiringItems(userId),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            
            final expiringItems = snapshot.data ?? [];
            
            if (expiringItems.isEmpty) {
              return GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.check_circle,
                      size: 48,
                      color: Colors.green,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'No items expiring soon',
                      style: theme.textTheme.titleMedium,
                    ),
                  ],
                ),
              );
            }
            
            return SizedBox(
              height: 120,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: expiringItems.length,
                itemBuilder: (context, index) {
                  final item = expiringItems[index];
                  final daysUntilExpiry = item.expiryDate != null
                      ? item.expiryDate!.difference(DateTime.now()).inDays
                      : 0;
                  
                  return Container(
                    width: 140,
                    margin: const EdgeInsets.only(right: 16),
                    child: GlassCard(
                      backgroundColor: daysUntilExpiry <= 2
                          ? Colors.red.withOpacity(0.1)
                          : daysUntilExpiry <= 5
                              ? Colors.orange.withOpacity(0.1)
                              : Colors.green.withOpacity(0.1),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            item.name,
                            style: theme.textTheme.titleMedium,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${item.quantity} ${item.unit}',
                            style: theme.textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            item.expiryDate != null
                                ? 'Expires in $daysUntilExpiry day${daysUntilExpiry != 1 ? 's' : ''}'
                                : 'No expiry date',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: daysUntilExpiry <= 2
                                  ? Colors.red
                                  : daysUntilExpiry <= 5
                                      ? Colors.orange
                                      : Colors.green,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ],
    );
  }
  
  Widget _buildQuickActions(BuildContext context) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: theme.textTheme.headlineMedium,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.add_circle,
                      size: 32,
                      color: Colors.green,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Add Recipe',
                      style: theme.textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.shopping_cart,
                      size: 32,
                      color: Colors.blue,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Shopping List',
                      style: theme.textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.auto_awesome,
                      size: 32,
                      color: Colors.purple,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'AI Recipe',
                      style: theme.textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.inventory_2,
                      size: 32,
                      color: Colors.orange,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Add Item',
                      style: theme.textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  Widget _buildNutritionSummary(BuildContext context, String userId) {
    final theme = Theme.of(context);
    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Today\'s Nutrition',
          style: theme.textTheme.headlineMedium,
        ),
        const SizedBox(height: 16),
        StreamBuilder<List<MealPlanModel>>(
          stream: Provider.of<MealPlanService>(context).getMealPlans(
            userId,
            startOfDay,
            endOfDay,
          ),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            
            final mealPlans = snapshot.data ?? [];
            
            if (mealPlans.isEmpty || mealPlans.first.nutritionSummary == null) {
              return GlassCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.pie_chart,
                      size: 48,
                      color: Colors.grey,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'No nutrition data available',
                      style: theme.textTheme.titleMedium,
                    ),
                  ],
                ),
              );
            }
            
            final nutritionSummary = mealPlans.first.nutritionSummary!;
            
            return GlassCard(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildNutritionItem(
                        context,
                        'Calories',
                        '${nutritionSummary['calories']}',
                        'kcal',
                        Colors.red,
                      ),
                      _buildNutritionItem(
                        context,
                        'Protein',
                        '${nutritionSummary['protein']}',
                        'g',
                        Colors.blue,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildNutritionItem(
                        context,
                        'Carbs',
                        '${nutritionSummary['carbs']}',
                        'g',
                        Colors.green,
                      ),
                      _buildNutritionItem(
                        context,
                        'Fat',
                        '${nutritionSummary['fat']}',
                        'g',
                        Colors.orange,
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
  
  Widget _buildNutritionItem(
    BuildContext context,
    String label,
    String value,
    String unit,
    Color color,
  ) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              value,
              style: theme.textTheme.titleLarge?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: theme.textTheme.bodyMedium,
        ),
        Text(
          unit,
          style: theme.textTheme.bodySmall?.copyWith(
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}

