import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../services/auth_service.dart';
import '../../services/recipe_service.dart';
import '../../models/recipe_model.dart';
import '../../widgets/glass_card.dart';

class AddEditRecipeScreen extends StatefulWidget {
  final String? recipeId; // If provided, we're editing an existing recipe

  const AddEditRecipeScreen({
    Key? key,
    this.recipeId,
  }) : super(key: key);

  @override
  _AddEditRecipeScreenState createState() => _AddEditRecipeScreenState();
}

class _AddEditRecipeScreenState extends State<AddEditRecipeScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _isInitialized = false;
  File? _imageFile;
  String _imageUrl = '';
  String? _errorMessage;

  // Form controllers
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _prepTimeController = TextEditingController(text: '15');
  final _cookTimeController = TextEditingController(text: '30');
  final _servingsController = TextEditingController(text: '4');

  // Nutrition controllers
  final _caloriesController = TextEditingController(text: '0');
  final _proteinController = TextEditingController(text: '0');
  final _carbsController = TextEditingController(text: '0');
  final _fatController = TextEditingController(text: '0');

  // Ingredients and instructions
  List<Map<String, String>> _ingredients = [
    {'name': '', 'quantity': '', 'unit': 'g', 'notes': ''}
  ];
  List<String> _instructions = [''];

  // Categories and tags
  List<String> _selectedCategories = [];
  List<String> _selectedCuisines = [];
  List<String> _selectedDietaryTypes = [];

  final List<String> _categories = [
    'Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snack', 'Appetizer'
  ];

  final List<String> _cuisines = [
    'Italian', 'Mexican', 'Asian', 'American', 'Mediterranean', 'Indian'
  ];

  final List<String> _dietaryTypes = [
    'Vegetarian', 'Vegan', 'Gluten-Free', 'Keto', 'Low-Carb', 'Dairy-Free'
  ];

  final List<String> _units = [
    'g', 'kg', 'ml', 'L', 'tsp', 'tbsp', 'cup', 'oz', 'lb', 'pcs'
  ];

  @override
  void initState() {
    super.initState();
    if (widget.recipeId != null) {
      _loadRecipe();
    } else {
      _isInitialized = true;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _prepTimeController.dispose();
    _cookTimeController.dispose();
    _servingsController.dispose();
    _caloriesController.dispose();
    _proteinController.dispose();
    _carbsController.dispose();
    _fatController.dispose();
    super.dispose();
  }

  Future<void> _loadRecipe() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final recipeService = Provider.of<RecipeService>(context, listen: false);
      final recipe = await recipeService.getRecipeById(widget.recipeId!);

      if (recipe != null) {
        // Set basic info
        _titleController.text = recipe.title;
        _descriptionController.text = recipe.description;
        _prepTimeController.text = recipe.prepTimeMinutes.toString();
        _cookTimeController.text = recipe.cookTimeMinutes.toString();
        _servingsController.text = recipe.servings.toString();
        _imageUrl = recipe.imageUrl;

        // Set nutrition info
        _caloriesController.text = recipe.nutritionInfo['calories'].toString();
        _proteinController.text = recipe.nutritionInfo['protein'].toString();
        _carbsController.text = recipe.nutritionInfo['carbs'].toString();
        _fatController.text = recipe.nutritionInfo['fat'].toString();

        // Set ingredients
        _ingredients = recipe.ingredients.map((ingredient) => {
          'name': ingredient.name,
          'quantity': ingredient.quantity,
          'unit': ingredient.unit,
          'notes': ingredient.notes ?? '',
        }).toList();

        // Set instructions
        _instructions = recipe.instructions;

        // Set categories and tags
        _selectedCategories = recipe.categories;
        _selectedCuisines = recipe.cuisineTypes;
        _selectedDietaryTypes = recipe.dietaryTypes;
      } else {
        _errorMessage = 'Recipe not found';
      }
    } catch (e) {
      print('Error loading recipe: $e');
      _errorMessage = 'Error loading recipe: $e';
    } finally {
      setState(() {
        _isLoading = false;
        _isInitialized = true;
      });
    }
  }

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
      }
    } catch (e) {
      print('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
    }
  }

  void _addIngredient() {
    setState(() {
      _ingredients.add({'name': '', 'quantity': '', 'unit': 'g', 'notes': ''});
    });
  }

  void _removeIngredient(int index) {
    if (_ingredients.length > 1) {
      setState(() {
        _ingredients.removeAt(index);
      });
    }
  }

  void _addInstruction() {
    setState(() {
      _instructions.add('');
    });
  }

  void _removeInstruction(int index) {
    if (_instructions.length > 1) {
      setState(() {
        _instructions.removeAt(index);
      });
    }
  }

  Future<void> _saveRecipe() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final recipeService = Provider.of<RecipeService>(context, listen: false);
      final authService = Provider.of<AuthService>(context, listen: false);

      final userData = await authService.getUserData();

      if (userData == null) {
        throw Exception('User not authenticated');
      }

      // Create ingredients list
      final ingredients = _ingredients.map((ingredient) => Ingredient(
        name: ingredient['name']!,
        quantity: ingredient['quantity']!,
        unit: ingredient['unit']!,
        notes: ingredient['notes']!.isNotEmpty ? ingredient['notes'] : null,
      )).toList();

      // Create nutrition info
      final nutritionInfo = {
        'calories': int.parse(_caloriesController.text),
        'protein': double.parse(_proteinController.text),
        'carbs': double.parse(_carbsController.text),
        'fat': double.parse(_fatController.text),
      };

      // Create recipe object
      final recipe = RecipeModel(
        id: widget.recipeId ?? '',
        title: _titleController.text,
        description: _descriptionController.text,
        imageUrl: _imageUrl,
        categories: _selectedCategories,
        cuisineTypes: _selectedCuisines,
        dietaryTypes: _selectedDietaryTypes,
        prepTimeMinutes: int.parse(_prepTimeController.text),
        cookTimeMinutes: int.parse(_cookTimeController.text),
        servings: int.parse(_servingsController.text),
        ingredients: ingredients,
        instructions: _instructions.where((instruction) => instruction.isNotEmpty).toList(),
        nutritionInfo: nutritionInfo,
        authorId: userData.uid,
        isAIGenerated: false,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      if (widget.recipeId != null) {
        // Update existing recipe
        await recipeService.updateRecipe(recipe, _imageFile);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Recipe updated successfully')),
        );
      } else {
        // Add new recipe
        final recipeId = await recipeService.addRecipe(recipe, _imageFile);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Recipe added successfully')),
        );
      }

      Navigator.pop(context);
    } catch (e) {
      print('Error saving recipe: $e');
      setState(() {
        _errorMessage = 'Error saving recipe: $e';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving recipe: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isEditing = widget.recipeId != null;

    if (!_isInitialized) {
      return Scaffold(
        appBar: AppBar(
          title: Text(isEditing ? 'Edit Recipe' : 'Add Recipe'),
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_errorMessage != null) {
      return Scaffold(
        appBar: AppBar(
          title: Text(isEditing ? 'Edit Recipe' : 'Add Recipe'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                size: 64,
                color: Colors.red,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                style: theme.textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Recipe' : 'Add Recipe'),
        actions: [
          TextButton.icon(
            onPressed: _isLoading ? null : _saveRecipe,
            icon: const Icon(Icons.save),
            label: const Text('Save'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Recipe Image
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    width: double.infinity,
                    height: 200,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                      image: _imageFile != null
                          ? DecorationImage(
                        image: FileImage(_imageFile!),
                        fit: BoxFit.cover,
                      )
                          : _imageUrl.isNotEmpty
                          ? DecorationImage(
                        image: NetworkImage(_imageUrl),
                        fit: BoxFit.cover,
                      )
                          : null,
                    ),
                    child: _imageFile == null && _imageUrl.isEmpty
                        ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add_a_photo,
                          size: 48,
                          color: theme.colorScheme.primary,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Add Recipe Photo',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.primary,
                          ),
                        ),
                      ],
                    )
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Basic Info
              Text(
                'Basic Information',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              GlassCard(
                child: Column(
                  children: [
                    // Title
                    TextFormField(
                      controller: _titleController,
                      decoration: const InputDecoration(
                        labelText: 'Recipe Title',
                        hintText: 'Enter recipe title',
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a title';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // Description
                    TextFormField(
                      controller: _descriptionController,
                      decoration: const InputDecoration(
                        labelText: 'Description',
                        hintText: 'Enter a brief description',
                      ),
                      maxLines: 3,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a description';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // Time and Servings
                    Row(
                      children: [
                        // Prep Time
                        Expanded(
                          child: TextFormField(
                            controller: _prepTimeController,
                            decoration: const InputDecoration(
                              labelText: 'Prep Time (min)',
                              hintText: 'Prep time',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (int.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),

                        // Cook Time
                        Expanded(
                          child: TextFormField(
                            controller: _cookTimeController,
                            decoration: const InputDecoration(
                              labelText: 'Cook Time (min)',
                              hintText: 'Cook time',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (int.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),

                        // Servings
                        Expanded(
                          child: TextFormField(
                            controller: _servingsController,
                            decoration: const InputDecoration(
                              labelText: 'Servings',
                              hintText: 'Servings',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (int.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Categories and Tags
              Text(
                'Categories & Tags',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Categories
                    Text(
                      'Categories',
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _categories.map((category) {
                        final isSelected = _selectedCategories.contains(category);
                        return FilterChip(
                          label: Text(category),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                _selectedCategories.add(category);
                              } else {
                                _selectedCategories.remove(category);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),

                    // Cuisines
                    Text(
                      'Cuisine Types',
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _cuisines.map((cuisine) {
                        final isSelected = _selectedCuisines.contains(cuisine);
                        return FilterChip(
                          label: Text(cuisine),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                _selectedCuisines.add(cuisine);
                              } else {
                                _selectedCuisines.remove(cuisine);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),

                    // Dietary Types
                    Text(
                      'Dietary Preferences',
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _dietaryTypes.map((diet) {
                        final isSelected = _selectedDietaryTypes.contains(diet);
                        return FilterChip(
                          label: Text(diet),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                _selectedDietaryTypes.add(diet);
                              } else {
                                _selectedDietaryTypes.remove(diet);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Ingredients
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Ingredients',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_circle),
                    onPressed: _addIngredient,
                    color: theme.colorScheme.primary,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              GlassCard(
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _ingredients.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Ingredient Name
                          Expanded(
                            flex: 3,
                            child: TextFormField(
                              initialValue: _ingredients[index]['name'],
                              decoration: const InputDecoration(
                                labelText: 'Ingredient',
                                hintText: 'e.g. Flour',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Required';
                                }
                                return null;
                              },
                              onChanged: (value) {
                                setState(() {
                                  _ingredients[index]['name'] = value;
                                });
                              },
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Quantity
                          Expanded(
                            flex: 2,
                            child: TextFormField(
                              initialValue: _ingredients[index]['quantity'],
                              decoration: const InputDecoration(
                                labelText: 'Quantity',
                                hintText: 'e.g. 200',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Required';
                                }
                                return null;
                              },
                              onChanged: (value) {
                                setState(() {
                                  _ingredients[index]['quantity'] = value;
                                });
                              },
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Unit
                          Expanded(
                            flex: 2,
                            child: DropdownButtonFormField<String>(
                              value: _ingredients[index]['unit'],
                              decoration: const InputDecoration(
                                labelText: 'Unit',
                              ),
                              items: _units.map((unit) {
                                return DropdownMenuItem<String>(
                                  value: unit,
                                  child: Text(unit),
                                );
                              }).toList(),
                              onChanged: (value) {
                                if (value != null) {
                                  setState(() {
                                    _ingredients[index]['unit'] = value;
                                  });
                                }
                              },
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Remove Button
                          IconButton(
                            icon: const Icon(Icons.remove_circle),
                            onPressed: () => _removeIngredient(index),
                            color: Colors.red,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),

              // Instructions
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Instructions',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_circle),
                    onPressed: _addInstruction,
                    color: theme.colorScheme.primary,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              GlassCard(
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _instructions.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Step Number
                          Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                '${index + 1}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),

                          // Instruction Text
                          Expanded(
                            child: TextFormField(
                              initialValue: _instructions[index],
                              decoration: const InputDecoration(
                                labelText: 'Step',
                                hintText: 'Describe this step',
                              ),
                              maxLines: 3,
                              validator: (value) {
                                if (index == 0 && (value == null || value.isEmpty)) {
                                  return 'At least one instruction is required';
                                }
                                return null;
                              },
                              onChanged: (value) {
                                setState(() {
                                  _instructions[index] = value;
                                });
                              },
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Remove Button
                          IconButton(
                            icon: const Icon(Icons.remove_circle),
                            onPressed: () => _removeInstruction(index),
                            color: Colors.red,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),

              // Nutrition Information
              Text(
                'Nutrition Information',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              GlassCard(
                child: Column(
                  children: [
                    Row(
                      children: [
                        // Calories
                        Expanded(
                          child: TextFormField(
                            controller: _caloriesController,
                            decoration: const InputDecoration(
                              labelText: 'Calories',
                              hintText: 'kcal',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (int.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),

                        // Protein
                        Expanded(
                          child: TextFormField(
                            controller: _proteinController,
                            decoration: const InputDecoration(
                              labelText: 'Protein',
                              hintText: 'g',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (double.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        // Carbs
                        Expanded(
                          child: TextFormField(
                            controller: _carbsController,
                            decoration: const InputDecoration(
                              labelText: 'Carbs',
                              hintText: 'g',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (double.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),

                        // Fat
                        Expanded(
                          child: TextFormField(
                            controller: _fatController,
                            decoration: const InputDecoration(
                              labelText: 'Fat',
                              hintText: 'g',
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              if (double.tryParse(value) == null) {
                                return 'Invalid number';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              // Save Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveRecipe,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(isEditing ? 'Update Recipe' : 'Add Recipe'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

