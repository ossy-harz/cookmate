import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../services/auth_service.dart';
import '../../services/meal_plan_service.dart';
import '../../models/meal_plan_model.dart';
import '../../widgets/glass_card.dart';

class MealPlannerScreen extends StatefulWidget {
  const MealPlannerScreen({Key? key}) : super(key: key);

  @override
  _MealPlannerScreenState createState() => _MealPlannerScreenState();
}

class _MealPlannerScreenState extends State<MealPlannerScreen> {
  late DateTime _selectedDay;
  late DateTime _focusedDay;
  CalendarFormat _calendarFormat = CalendarFormat.week;
  
  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();
    _focusedDay = DateTime.now();
  }
  
  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final theme = Theme.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meal Planner'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              _showAddMealDialog(context);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Calendar
          GlassCard(
            borderRadius: 0,
            padding: EdgeInsets.zero,
            child: TableCalendar(
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: _focusedDay,
              calendarFormat: _calendarFormat,
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              onFormatChanged: (format) {
                setState(() {
                  _calendarFormat = format;
                });
              },
              calendarStyle: CalendarStyle(
                todayDecoration: BoxDecoration(
                  color: theme.colorScheme.primary.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                selectedDecoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  shape: BoxShape.circle,
                ),
                markersMaxCount: 3,
              ),
              headerStyle: HeaderStyle(
                formatButtonTextStyle: TextStyle(
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
                formatButtonDecoration: BoxDecoration(
                  border: Border.all(color: theme.colorScheme.primary),
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          
          // Meal list for selected day
          Expanded(
            child: FutureBuilder(
              future: authService.getUserData(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }
                
                final userData = snapshot.data;
                
                if (userData == null) {
                  return const Center(child: Text('User data not found'));
                }
                
                return _buildMealList(context, userData.uid);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddMealDialog(context);
        },
        child: const Icon(Icons.add),
      ),
    );
  }
  
  Widget _buildMealList(BuildContext context, String userId) {
    final theme = Theme.of(context);
    final startOfDay = DateTime(_selectedDay.year, _selectedDay.month, _selectedDay.day);
    final endOfDay = DateTime(_selectedDay.year, _selectedDay.month, _selectedDay.day, 23, 59, 59);
    
    return StreamBuilder<List<MealPlanModel>>(
      stream: Provider.of<MealPlanService>(context).getMealPlans(
        userId,
        startOfDay,
        endOfDay,
      ),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        
        final mealPlans = snapshot.data ?? [];
        
        if (mealPlans.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.restaurant,
                  size: 64,
                  color: Colors.grey,
                ),
                const SizedBox(height: 16),
                Text(
                  'No meals planned for ${DateFormat('MMMM d, yyyy').format(_selectedDay)}',
                  style: theme.textTheme.titleLarge,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    _showAddMealDialog(context);
                  },
                  icon: const Icon(Icons.add),
                  label: const Text('Add Meal'),
                ),
              ],
            ),
          );
        }
        
        final meals = mealPlans.first.meals;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              DateFormat('EEEE, MMMM d, yyyy').format(_selectedDay),
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: 16),
            
            // Breakfast
            _buildMealTypeSection(context, 'Breakfast', meals.where((m) => m.mealType.toLowerCase() == 'breakfast').toList()),
            const SizedBox(height: 16),
            
            // Lunch
            _buildMealTypeSection(context, 'Lunch', meals.where((m) => m.mealType.toLowerCase() == 'lunch').toList()),
            const SizedBox(height: 16),
            
            // Dinner
            _buildMealTypeSection(context, 'Dinner', meals.where((m) => m.mealType.toLowerCase() == 'dinner').toList()),
            const SizedBox(height: 16),
            
            // Snacks
            _buildMealTypeSection(context, 'Snacks', meals.where((m) => m.mealType.toLowerCase() == 'snack').toList()),
            
            // Nutrition Summary
            if (mealPlans.first.nutritionSummary != null) ...[
              const SizedBox(height: 24),
              Text(
                'Nutrition Summary',
                style: theme.textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              GlassCard(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNutritionItem(
                      context,
                      'Calories',
                      '${mealPlans.first.nutritionSummary!['calories']}',
                      'kcal',
                      Colors.red,
                    ),
                    _buildNutritionItem(
                      context,
                      'Protein',
                      '${mealPlans.first.nutritionSummary!['protein']}',
                      'g',
                      Colors.blue,
                    ),
                    _buildNutritionItem(
                      context,
                      'Carbs',
                      '${mealPlans.first.nutritionSummary!['carbs']}',
                      'g',
                      Colors.green,
                    ),
                    _buildNutritionItem(
                      context,
                      'Fat',
                      '${mealPlans.first.nutritionSummary!['fat']}',
                      'g',
                      Colors.orange,
                    ),
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }
  
  Widget _buildMealTypeSection(BuildContext context, String mealType, List<MealEntry> meals) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              mealType,
              style: theme.textTheme.titleLarge,
            ),
            IconButton(
              icon: const Icon(Icons.add_circle_outline),
              onPressed: () {
                _showAddMealDialog(context, initialMealType: mealType.toLowerCase());
              },
            ),
          ],
        ),
        const SizedBox(height: 8),
        meals.isEmpty
            ? GlassCard(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'No $mealType planned',
                      style: theme.textTheme.bodyLarge,
                    ),
                  ),
                ),
              )
            : Column(
                children: meals.map((meal) => _buildMealCard(context, meal)).toList(),
              ),
      ],
    );
  }
  
  Widget _buildMealCard(BuildContext context, MealEntry meal) {
    final theme = Theme.of(context);
    final authService = Provider.of<AuthService>(context, listen: false);
    
    return Dismissible(
      key: Key(meal.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20.0),
        color: Colors.red,
        child: const Icon(
          Icons.delete,
          color: Colors.white,
        ),
      ),
      confirmDismiss: (direction) async {
        return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Confirm'),
              content: const Text('Are you sure you want to remove this meal?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('Delete'),
                ),
              ],
            );
          },
        );
      },
      onDismissed: (direction) async {
        final userData = await authService.getUserData();
        if (userData != null) {
          Provider.of<MealPlanService>(context, listen: false).removeMealFromDate(
            userData.uid,
            _selectedDay,
            meal.id,
          );
        }
      },
      child: Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: meal.recipeImageUrl != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    meal.recipeImageUrl!,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                  ),
                )
              : Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.restaurant,
                    color: theme.colorScheme.primary,
                  ),
                ),
          title: Text(meal.recipeName),
          subtitle: Text('${meal.servings} serving${meal.servings > 1 ? 's' : ''}'),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: () async {
                  final userData = await authService.getUserData();
                  if (userData != null && meal.servings > 1) {
                    Provider.of<MealPlanService>(context, listen: false).updateMealServings(
                      userData.uid,
                      _selectedDay,
                      meal.id,
                      meal.servings - 1,
                    );
                  }
                },
              ),
              Text('${meal.servings}'),
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () async {
                  final userData = await authService.getUserData();
                  if (userData != null) {
                    Provider.of<MealPlanService>(context, listen: false).updateMealServings(
                      userData.uid,
                      _selectedDay,
                      meal.id,
                      meal.servings + 1,
                    );
                  }
                },
              ),
            ],
          ),
          onTap: () {
            // Navigate to recipe details
            Navigator.pushNamed(context, '/recipe-details', arguments: meal.recipeId);
          },
        ),
      ),
    );
  }
  
  Widget _buildNutritionItem(
    BuildContext context,
    String label,
    String value,
    String unit,
    Color color,
  ) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        Text(
          value,
          style: theme.textTheme.headlineSmall?.copyWith(
            color: color,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          unit,
          style: theme.textTheme.bodySmall?.copyWith(
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: theme.textTheme.bodyMedium,
        ),
      ],
    );
  }
  
  void _showAddMealDialog(BuildContext context, {String? initialMealType}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add Meal'),
          content: const Text('Choose an option to add a meal to your plan:'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Navigate to recipe browser
                Navigator.pushNamed(
                  context,
                  '/recipes',
                  arguments: {
                    'selectMode': true,
                    'date': _selectedDay,
                    'mealType': initialMealType ?? 'breakfast',
                  },
                );
              },
              child: const Text('Browse Recipes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Navigate to AI recipe generator
                Navigator.pushNamed(
                  context,
                  '/ai-recipe',
                  arguments: {
                    'date': _selectedDay,
                    'mealType': initialMealType ?? 'breakfast',
                  },
                );
              },
              child: const Text('Generate with AI'),
            ),
          ],
        );
      },
    );
  }
}

