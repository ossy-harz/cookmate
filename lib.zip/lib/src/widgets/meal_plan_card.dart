import 'package:flutter/material.dart';
import '../models/meal_plan.dart';
import 'glass_card.dart';

class MealPlanCard extends StatelessWidget {
  final MealPlan mealPlan;
  final VoidCallback onTap;

  const MealPlanCard({
    Key? key,
    required this.mealPlan,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return GlassCard(
      height: 150,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date and Meal Type
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _formatDate(mealPlan.date),
                  style: theme.textTheme.titleLarge,
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _getMealTypeColor(mealPlan.mealType),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    mealPlan.mealType,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            
            // Recipe Name
            Text(
              mealPlan.recipeName,
              style: theme.textTheme.headlineMedium,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            
            // Nutritional Info
            Row(
              children: [
                _nutritionItem(context, 'Calories', '${mealPlan.calories} cal', Icons.local_fire_department),
                _nutritionItem(context, 'Protein', '${mealPlan.protein}g', Icons.fitness_center),
                _nutritionItem(context, 'Carbs', '${mealPlan.carbs}g', Icons.grain),
                _nutritionItem(context, 'Fat', '${mealPlan.fat}g', Icons.opacity),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _nutritionItem(BuildContext context, String label, String value, IconData icon) {
    final theme = Theme.of(context);
    
    return Expanded(
      child: Row(
        children: [
          Icon(icon, size: 16, color: theme.colorScheme.primary),
          const SizedBox(width: 4),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: theme.textTheme.bodySmall,
              ),
              Text(
                value,
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    if (date.year == now.year && date.month == now.month && date.day == now.day) {
      return 'Today';
    } else if (date.year == now.year && date.month == now.month && date.day == now.day + 1) {
      return 'Tomorrow';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
  
  Color _getMealTypeColor(String mealType) {
    switch (mealType.toLowerCase()) {
      case 'breakfast':
        return Colors.orange;
      case 'lunch':
        return Colors.green;
      case 'dinner':
        return Colors.indigo;
      case 'snack':
        return Colors.purple;
      default:
        return Colors.blue;
    }
  }
}

