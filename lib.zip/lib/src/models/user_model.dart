import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String email;
  final String? displayName;
  final String? photoURL;
  final List<String> dietaryPreferences;
  final List<String> allergies;
  final Map<String, dynamic>? healthGoals;
  final DateTime createdAt;
  final DateTime lastUpdated;

  UserModel({
    required this.uid,
    required this.email,
    this.displayName,
    this.photoURL,
    this.dietaryPreferences = const [],
    this.allergies = const [],
    this.healthGoals,
    required this.createdAt,
    required this.lastUpdated,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      uid: json['uid'],
      email: json['email'],
      displayName: json['displayName'],
      photoURL: json['photoURL'],
      dietaryPreferences: List<String>.from(json['dietaryPreferences'] ?? []),
      allergies: List<String>.from(json['allergies'] ?? []),
      healthGoals: json['healthGoals'],
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      lastUpdated: (json['lastUpdated'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'photoURL': photoURL,
      'dietaryPreferences': dietaryPreferences,
      'allergies': allergies,
      'healthGoals': healthGoals,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastUpdated': Timestamp.fromDate(lastUpdated),
    };
  }

  UserModel copyWith({
    String? displayName,
    String? photoURL,
    List<String>? dietaryPreferences,
    List<String>? allergies,
    Map<String, dynamic>? healthGoals,
  }) {
    return UserModel(
      uid: this.uid,
      email: this.email,
      displayName: displayName ?? this.displayName,
      photoURL: photoURL ?? this.photoURL,
      dietaryPreferences: dietaryPreferences ?? this.dietaryPreferences,
      allergies: allergies ?? this.allergies,
      healthGoals: healthGoals ?? this.healthGoals,
      createdAt: this.createdAt,
      lastUpdated: DateTime.now(),
    );
  }
}

