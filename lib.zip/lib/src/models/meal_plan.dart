class MealPlan {
  final String id;
  final DateTime date;
  final String mealType;
  final String recipeId;
  final String recipeName;
  final int servings;
  final int calories;
  final double protein;
  final double carbs;
  final double fat;
  final String userId;
  final DateTime createdAt;

  MealPlan({
    required this.id,
    required this.date,
    required this.mealType,
    required this.recipeId,
    required this.recipeName,
    required this.servings,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
    required this.userId,
    required this.createdAt,
  });

  factory MealPlan.fromJson(Map<String, dynamic> json) {
    return MealPlan(
      id: json['id'],
      date: DateTime.parse(json['date']),
      mealType: json['mealType'],
      recipeId: json['recipeId'],
      recipeName: json['recipeName'],
      servings: json['servings'],
      calories: json['calories'],
      protein: (json['protein'] as num).toDouble(),
      carbs: (json['carbs'] as num).toDouble(),
      fat: (json['fat'] as num).toDouble(),
      userId: json['userId'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'mealType': mealType,
      'recipeId': recipeId,
      'recipeName': recipeName,
      'servings': servings,
      'calories': calories,
      'protein': protein,
      'carbs': carbs,
      'fat': fat,
      'userId': userId,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}

/// MealPlanModel now extends MealPlan so it can be used anywhere a MealPlan is expected.
class MealPlanModel extends MealPlan {
  MealPlanModel({
    required String id,
    required DateTime date,
    required String mealType,
    required String recipeId,
    required String recipeName,
    required int servings,
    required int calories,
    required double protein,
    required double carbs,
    required double fat,
    required String userId,
    required DateTime createdAt,
  }) : super(
    id: id,
    date: date,
    mealType: mealType,
    recipeId: recipeId,
    recipeName: recipeName,
    servings: servings,
    calories: calories,
    protein: protein,
    carbs: carbs,
    fat: fat,
    userId: userId,
    createdAt: createdAt,
  );

  factory MealPlanModel.fromJson(Map<String, dynamic> json) {
    return MealPlanModel(
      id: json['id'],
      date: DateTime.parse(json['date']),
      mealType: json['mealType'],
      recipeId: json['recipeId'],
      recipeName: json['recipeName'],
      servings: json['servings'],
      calories: json['calories'],
      protein: (json['protein'] as num).toDouble(),
      carbs: (json['carbs'] as num).toDouble(),
      fat: (json['fat'] as num).toDouble(),
      userId: json['userId'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }
}
